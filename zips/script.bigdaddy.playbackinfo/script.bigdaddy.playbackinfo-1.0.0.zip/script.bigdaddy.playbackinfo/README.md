# BigDaddy Playback Info

An on-demand Kodi 22 playback overlay targeting
[CroqueMr LibreELEC x86 DV R1.0.0-Beta4](https://github.com/CroqueMr/libreelec-x86-DV/releases/tag/R1.0.0-Beta4).

This is a focused derivative, **not a full feature port of TinyPPI**. Selected
portable formatting helpers are adapted from CE-Repo/script.tinyppi commit
`c162ba174dfab3a07615c44b7270a803a3e199ce`. The overlay, lifecycle, package and
artwork are new. This project is not endorsed by TinyPPI's authors.

## Install and open

In the bigdaddy-cpm Kodi repository, install **Program add-ons > BigDaddy
Playback Info**. Update **Arctic Fuse 3 (BigDaddy)** to 1.0.1 or newer, start a
video, and select the playback-info icon on the video OSD. Installing this
add-on does not switch skins or change your settings.

You can also run `RunScript(script.bigdaddy.playbackinfo)` from a keymap.
Launching it a second time toggles it closed. Back or the Close button closes
it; playback stopping or Kodi exiting also stops its worker. It refreshes once
per second, only while open. There is no background service or web server.

Example keymap (merge into your existing file; do not overwrite other bindings):

```xml
<keymap>
  <FullscreenVideo>
    <keyboard><f8>RunScript(script.bigdaddy.playbackinfo)</f8></keyboard>
  </FullscreenVideo>
</keymap>
```

## Readings and limits

- Source video codec, decoder, dimensions, frame rate, HDR, pixel format,
  bitrate and deinterlacing method.
- Audio codec, channel layout/count, sample rate/depth, language and passthrough.
- Subtitles, CPU, memory and the explicitly labelled **GUI** resolution.
- **Kodi / DV diagnostics** opens Kodi's native process-info window. Beta4's
  DV telemetry is available there when its enhanced information is enabled;
  BigDaddy Arctic Fuse 3 displays supported non-empty native DV fields.

Missing readings say **Not reported**, never a fabricated zero/SDR. Source HDR
does not establish the TV's current HDMI signal, source pixel format is not
the HDMI transport format, and GUI resolution is not the playback signal.
We do not guess Atmos height channels. Kodi determines which metrics it exposes.
Native DV values are not copied into this overlay: they only refresh while
Kodi's own process-info window is open.

No CoreELEC/Amlogic sysfs controls, VS10 switches, DRM writes, automatic font or
skin modifications, sidedata dependency, codec-logo splash, or web dashboard.
The default skin XML uses the conventional `font12`/`font13` skin fonts, present
in the target Arctic Fuse and Estuary skins. Other skins need on-device testing.
This is statically checked and unit-tested; validation is not a substitute for
playback testing on the target device.

## Source, licences and reproducible build

Source: https://github.com/bigdaddy-cpm/script.bigdaddy.playbackinfo

Code and new artwork: AGPL-3.0-or-later. See LICENSE, NOTICE and UPSTREAM-NOTICE.
No upstream branding, logos, artwork, fonts, or screenshots are distributed.
Modified/adapted files and new implementation dated **2026-10-20**.

With Python 3.11 or newer:

```sh
python -m unittest discover -s tests -v
python tools/build_release.py
```

The build validates Python/XML and creates original code-generated interface
textures/icon, an explicit runtime-file package, and a SHA-256 checksum in dist/.
All source needed to build the package is public. No network access is used.
