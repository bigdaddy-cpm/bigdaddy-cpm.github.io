# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (c) 2026 U3knOwn
# Copyright (c) 2026 bigdaddy-cpm
"""Adapted 2026-10-20 from TinyPPI core/helpers.py and core/utils.py.

Keep only portable FPS formatting and unknown-label handling. Do not infer
output frames or dropped frames from absent Amlogic sysfs counters.
"""
import math

_FORMAT_FPS_TARGETS = ((23.976, 0.02), (29.97, 0.02), (59.94, 0.02), (60.0, 0.01))


def format_fps(value):
    try:
        fps = float(value)
    except (TypeError, ValueError):
        return ""
    if not math.isfinite(fps) or fps <= 0:
        return ""
    for target, tolerance in _FORMAT_FPS_TARGETS:
        if abs(fps - target) <= tolerance:
            fps = target
            break
    return f"{fps:.3f}".rstrip("0").rstrip(".")


def known(label, value):
    """An unrecognised Kodi label can echo its name instead of returning ''."""
    if value is None or value == label:
        return ""
    return str(value).strip()
