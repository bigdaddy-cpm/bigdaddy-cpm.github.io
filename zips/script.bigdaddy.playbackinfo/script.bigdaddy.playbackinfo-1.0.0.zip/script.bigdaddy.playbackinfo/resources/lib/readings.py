# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (c) 2026 bigdaddy-cpm
"""Read-only Kodi labels. Never confuse source HDR with HDMI output state."""
from formatting import format_fps, known

UNAVAILABLE = "Not reported"


def collect(get_label, get_condition):
    """Collect one snapshot; injected readers also allow offline unit tests."""
    cache = {}

    def info(label):
        if label not in cache:
            cache[label] = known(label, get_label(label))
        return cache[label]

    def join(*values):
        return " / ".join(value for value in values if value)

    def positive(label, suffix):
        value = info(label)
        # Locale-formatted rates are displayed as reported, not parsed as floats.
        return value + suffix if value and value not in ("0", "0.0") else ""

    codec = info("VideoPlayer.VideoCodec")
    decoder = info("Player.Process(videodecoder)")
    hw = get_condition("Player.Process(videohwdecoder)")
    width = info("Player.Process(videowidth)")
    height = info("Player.Process(videoheight)")
    resolution = ""
    if width and height and width != "0" and height != "0":
        resolution = f"{width} x {height}"
        scan = info("Player.Process(videoscantype)")
        if scan:
            resolution += f" ({scan})"
    fps = format_fps(info("Player.Process(videofps)"))
    hdr = info("VideoPlayer.HdrType")
    hdr = {"hdr10": "HDR10", "hdr10plus": "HDR10+", "dolbyvision": "Dolby Vision",
           "hlg": "HLG", "sdr": "SDR"}.get(hdr.lower(), hdr)
    bitrate = info("Player.Process(videolivebitrate)")
    if not bitrate:
        # The live labels already contain units; VideoBitrate does not (kbps).
        rate = positive("VideoPlayer.VideoBitrate", " kb/s")
        bitrate = rate + " (stream)" if rate else ""

    audio_codec = info("VideoPlayer.AudioCodec")
    audio = {}
    if audio_codec:
        channels = info("Player.Process(audiochannels)")
        if not channels:
            # A count is NOT necessarily a speaker layout or Atmos height count.
            channels = positive("VideoPlayer.AudioChannels", " channels")
        audio = {
            "AudioCodec": audio_codec,
            "AudioLayout": channels,
            "AudioFormat": join(positive("Player.Process(audiosamplerate)", " Hz"),
                                positive("Player.Process(audiobitspersample)", " bit")),
            "AudioLanguage": info("VideoPlayer.AudioLanguage"),
            "AudioOutput": "Passthrough" if get_condition("Player.Passthrough") else "Decoded by Kodi",
        }

    subtitles = "Off"
    if get_condition("VideoPlayer.SubtitlesEnabled"):
        subtitles = join(info("VideoPlayer.SubtitlesLanguage"), info("VideoPlayer.SubtitleCodec")) or "On (details unavailable)"

    result = {
        "Title": info("VideoPlayer.Title") or "Playing video",
        "VideoCodec": codec,
        "Decoder": join(decoder, "Hardware" if hw else "Software") if decoder else "",
        "Resolution": resolution,
        "FrameRate": fps + " fps (source)" if fps else "",
        "SourceHDR": hdr,
        "PixelFormat": info("Player.Process(pixformat)"),
        "VideoBitrate": bitrate,
        "Deinterlace": info("Player.Process(deintmethod)"),
        "AudioCodec": "No audio" if not audio_codec else audio_codec,
        "AudioLayout": "", "AudioFormat": "", "AudioLanguage": "", "AudioOutput": "",
        "Subtitles": subtitles,
        "CPU": info("System.CpuUsage"),
        "Memory": join(positive("System.Memory(used)", " used"),
                       positive("System.Memory(free)", " free")),
        # This is Kodi's GUI resolution, NOT proof of the HDMI output signal.
        "GUIResolution": info("System.ScreenResolution"),
    }
    result.update(audio)
    return {key: value or UNAVAILABLE for key, value in result.items()}
