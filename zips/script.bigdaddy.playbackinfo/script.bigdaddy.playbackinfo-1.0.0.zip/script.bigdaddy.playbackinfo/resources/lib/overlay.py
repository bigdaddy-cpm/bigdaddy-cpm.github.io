# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (c) 2026 bigdaddy-cpm
"""An on-demand overlay. No sysfs, DRM ioctls, skin edits or network calls."""
import fcntl
import os
import threading

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from readings import collect

ADDON_ID = "script.bigdaddy.playbackinfo"
CLOSE_PROPERTY = "BigDaddy.PlaybackInfo.Close"
TITLE = "BigDaddy Playback Info"
BACK_ACTIONS = (9, 10, 92, 216)  # parent dir, previous menu, nav back, back


class PlaybackInfo(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.stop_event = threading.Event()
        self.worker = None
        self.native_requested = False
        self.last_values = {}
        self.home = xbmcgui.Window(10000)
        self.monitor = xbmc.Monitor()
        self.player = xbmc.Player()

    def onInit(self):
        if self.worker is None:
            self.worker = threading.Thread(target=self._refresh, name="BigDaddyPlaybackInfo", daemon=True)
            self.worker.start()

    def _refresh(self):
        try:
            while not self.stop_event.is_set() and not self.monitor.abortRequested():
                if not self.player.isPlayingVideo() or self.home.getProperty(CLOSE_PROPERTY) == "1":
                    break
                values = collect(xbmc.getInfoLabel, xbmc.getCondVisibility)
                for key, value in values.items():
                    if self.last_values.get(key) != value:
                        self.setProperty("BDPI." + key, value)
                self.last_values = values
                self.stop_event.wait(1.0)
        except Exception as exc:
            # Do not log media paths, credentials or stream URLs.
            xbmc.log(f"[{ADDON_ID}] Overlay refresh stopped: {type(exc).__name__}", xbmc.LOGWARNING)
        finally:
            self.close()

    def onAction(self, action):
        if action.getId() in BACK_ACTIONS:
            self.close()

    def onClick(self, control_id):
        if control_id == 100:
            self.native_requested = True
            self.close()
        elif control_id == 101:
            self.close()

    def close(self):
        self.stop_event.set()
        super().close()

    def finish(self):
        self.stop_event.set()
        if self.worker and self.worker is not threading.current_thread():
            self.worker.join(timeout=3.0)


def run():
    addon = xbmcaddon.Addon(ADDON_ID)
    player = xbmc.Player()
    if not player.isPlayingVideo():
        xbmcgui.Dialog().notification(TITLE, "Start a video, then open Playback Info.")
        return
    try:
        major = int(xbmc.getInfoLabel("System.BuildVersion").split(".")[0])
    except (ValueError, IndexError):
        major = 0
    if major < 22:
        xbmcgui.Dialog().notification(TITLE, "This version requires Kodi 22 or newer.")
        return

    # Linux advisory lock is released by the OS on exit/crash. A second launch
    # requests close without creating another overlay or polling thread.
    profile = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
    os.makedirs(profile, exist_ok=True)
    home = xbmcgui.Window(10000)
    native = False
    with open(os.path.join(profile, "overlay.lock"), "a", encoding="utf-8") as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            home.setProperty(CLOSE_PROPERTY, "1")
            return
        home.clearProperty(CLOSE_PROPERTY)
        dialog = None
        try:
            xbmc.executebuiltin("Dialog.Close(videoosd,true)")
            xbmc.executebuiltin("ActivateWindow(fullscreenvideo)")
            dialog = PlaybackInfo("playback-info.xml", addon.getAddonInfo("path"), "Default", "1080i")
            dialog.doModal()
            native = dialog.native_requested
        finally:
            if dialog is not None:
                dialog.finish()
                del dialog
            home.clearProperty(CLOSE_PROPERTY)
            fcntl.flock(lock, fcntl.LOCK_UN)

    if native and player.isPlayingVideo():
        # Native DV telemetry belongs to this window and updates only while it
        # is open. Do not scrape stale Window(playerprocessinfo) properties.
        xbmc.executebuiltin("Action(PlayerProcessInfo)")
