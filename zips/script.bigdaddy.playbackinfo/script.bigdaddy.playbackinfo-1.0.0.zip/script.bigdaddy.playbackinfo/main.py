# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (c) 2026 bigdaddy-cpm
"""Kodi script entry point. No service is installed or started."""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "lib"))

from overlay import run  # noqa: E402

if __name__ == "__main__":
    run()
